package carrera;
import java.util.Random;
/**
 * @version 0.0.1
 * Created by radge on 27/06/17.
 */
public class Liebre {
    private int posicionActual = 1;

    private Random random = new Random();

    private final int DORMIR = 0; // %20
    private final int GRAN_SALTO = 9; // %20
    private final int GRAN_RESBALON = 12; // %10
    private final int PEQUENO_SALTO = 1; // %30
    private final int PEQUENO_RESBALON = 2; // %20

    public void hacerMovimiento() {
        int aleatorio = random.nextInt(10) + 1;
        if(aleatorio >= 1 && aleatorio <= 2) {
            dormir();
        } else if(aleatorio >= 3 && aleatorio <= 4) {
            darGranSalto();
        } else if(aleatorio == 5) {
            darGranResbalon();
        } else if(aleatorio >= 6 && aleatorio <= 8) {
            darPequenoSalto();
        } else if(aleatorio >= 9 && aleatorio <= 10) {
            darPequenoResbalon();
        }
    }

    private void dormir() {
        // no se hace nada
    }

    private void darGranSalto() {
        aumentarPosicionActual(GRAN_SALTO);
    }

    private void darGranResbalon() {
        disminuirPosicionActual(GRAN_RESBALON);
    }

    private void darPequenoSalto() {
        aumentarPosicionActual(PEQUENO_SALTO);
    }

    private void darPequenoResbalon() {
        disminuirPosicionActual(PEQUENO_RESBALON);
    }

    private void aumentarPosicionActual(int posiciones) {
        posicionActual += posiciones;
        if(posicionActual > 70) {
            posicionActual = 70;
        }
    }

    private void disminuirPosicionActual(int posiciones) {
        posicionActual -= posiciones;
        if(isPosicionIlegal()) {
            legalizarPosicionActual();
        }
    }

    private boolean isPosicionIlegal() {
        boolean ilegal = false;
        if(posicionActual <= 0) {
            ilegal = true;
        }
        return ilegal;
    }

    private void legalizarPosicionActual() {
        posicionActual = 1;
    }

    public int getPosicionActual() {
        return posicionActual;
    }
}
